chrome.storage.onChanged.addListener((changes) => {
  if (changes.focusEnabled) {
    const enabled = changes.focusEnabled.newValue;

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon128.png",
      title: "YouTube Focus Mode",
      message: enabled
        ? "Focus Mode ENABLED ✅"
        : "Focus Mode DISABLED ❌"
    });
  }
});

// Flavortown registration header (already done)
fetch("https://example.com", {
  headers: {
    "X-Flavortown-Ext-1812": "true"
  }
}).catch(() => {});
