function hideDistractions() {
  chrome.storage.sync.get(["focusEnabled"], (result) => {
    if (result.focusEnabled === false) return;

    const selectors = [
      "#comments",
      "#secondary",
      "ytd-rich-grid-renderer",
      "ytd-mini-guide-renderer"
    ];

    selectors.forEach(selector => {
      const el = document.querySelector(selector);
      if (el) el.style.display = "none";
    });
  });
}

setInterval(hideDistractions, 2000);
