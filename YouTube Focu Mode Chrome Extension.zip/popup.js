const toggle = document.getElementById("toggle");

// Load saved state
chrome.storage.sync.get(["focusEnabled"], (result) => {
  toggle.checked = result.focusEnabled ?? true;
});

// Save state on change
toggle.addEventListener("change", () => {
  chrome.storage.sync.set({ focusEnabled: toggle.checked });
});
